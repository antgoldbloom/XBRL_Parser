


data_path = '../data/'

with open(f"{data_path}logs/__OVERALL__/multi_match.json") as json_file:
    m_dict = json.load(json_file)