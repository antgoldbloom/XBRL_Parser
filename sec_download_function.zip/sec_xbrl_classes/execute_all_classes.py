from company_statements_xbrl import CompanyStatementsXBRL
from company_statements_json import CompanyStatementsJSON
from company_statements_csv import CompanyStatementCSV
from company_statements_timeseries import CompanyStatementTimeseries
from company_statements_standardize import CompanyStatementStandardize 
from company_stockrow_reconcilation import CompanyStockrowReconcilation 


from utils import setup_logging 

from time import time
from datetime import datetime
import random

from google.cloud import storage

import os
import sys

def already_uploaded(bucket_name, ticker):

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    key_files = ['Income Statement.csv','Balance Sheet.csv','Cash Flow.csv']
    key_folder = f'{ticker}/Clean Statements/'

    key_files_exist = True
    for file in key_files:    
        stats = storage.Blob(bucket=bucket, name=f'{key_folder}{file}').exists(storage_client)

        if stats == False:

            key_files_exist = False
            break

    return key_files_exist

def upload_statement_files_and_logs(bucket_name, data_path,ticker):
    """Uploads a file to the bucket."""
    # bucket_name = "your-bucket-name"
    # source_file_name = "local/path/to/file"
    # destination_blob_name = "storage-object-name"
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    
    files_uploaded = []
    
    timeseries_path = f'{data_path}timeseries/{ticker}/'
    log_path = f'{data_path}logs/ticker/'
    
    
    for dirname, _, filenames in os.walk(timeseries_path):
        for filename in filenames:

            source_file_name = f'{dirname}/{filename}'
            destination_blob_name = f'{dirname[len(data_path):]}/{filename}'
        
    
            blob = bucket.blob(destination_blob_name)

            blob.upload_from_filename(source_file_name)

            files_uploaded.append(filename)

    for dirname, _, filenames in os.walk(log_path):
        for filename in filenames:

            source_file_name = f'{dirname}/{filename}'
            destination_blob_name = f'{dirname[len(data_path)]}/{filename}'
            
            blob = bucket.blob(destination_blob_name)
            blob.upload_from_filename(source_file_name)

            files_uploaded.append(filename)

            
    print(f"Files uploaded: {', '.join(files_uploaded)}")



def xbrl_to_statement(ticker,data_path,overall_logger,bucket_name,update_only=True):
    if already_uploaded(bucket_name,ticker):
        overall_logger.info(f'{ticker} already uploaded')
    else:
    
        try:
            company_xbrl = CompanyStatementsXBRL(ticker,data_path,overall_logger,update_only)
        except:
            overall_logger.error('XBRL: {}. {}, line: {} in {}'.format(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2].tb_lineno,sys.exc_info()[2].tb_lineno))
        else:
            try:
                company_json = CompanyStatementsJSON(ticker,data_path,overall_logger,update_only)
            except:
                overall_logger.error('JSON: {}. {}, line: {} in {}'.format(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2].tb_lineno,sys.exc_info()[2].tb_lineno))
            else:
                try:
                    company_csv = CompanyStatementCSV(ticker,data_path,overall_logger,update_only)
                except:
                    overall_logger.error('CSV: {}. {}, line: {} in {}'.format(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2].tb_lineno,sys.exc_info()[2].tb_lineno))
                else:
                    try:
                        company_timeseries = CompanyStatementTimeseries(ticker,data_path,overall_logger,update_only)
                    except:
                        overall_logger.error('TIMESERIES: {}. {}, line: {} in {}'.format(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2].tb_lineno,sys.exc_info()[2].tb_lineno))
                    else:
                        try:
                            company_standard = CompanyStatementStandardize(ticker,data_path,overall_logger)
                        except:
                            overall_logger.error('STANDARDIZED: {}. {}, line: {} in {}'.format(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2].tb_lineno,sys.exc_info()[2].tb_lineno))
                        else:
                            try:
                                upload_statement_files_and_logs(bucket_name,data_path,ticker)
                                company_stockrow = CompanyStockrowReconcilation(ticker,data_path,overall_logger)
                            except:
                                overall_logger.error('RECONCILE: {}. {}, line: {} in {}'.format(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2].tb_lineno,sys.exc_info()[2].tb_lineno))

  

#



